# RigExpert oracle source snapshot

Retrieved 2026-10-14. AntScope2 pin: **901923c3029e661385fdf88dc7b089cc2263f609**, committed 2026-09-30T15:21:27Z.

This is a research subset, not a buildable AntScope2 checkout. Manufacturer code remains covered by [its MIT notice](./AntScope2/LICENSE.txt); bundled third-party licensing needs separate review before reuse.

Official browser text extracts retain source line/page labels. They are not original PDF/HTML bytes: raw download attempts returned HTTP Error 403: Forbidden. The retrieval manifest records this distinction.

Each file has a SHA-256 in [manifest.json](./manifest.json). Source-derived illustrative vectors live one directory up; hardware captures have not been collected.

| Local file | Provenance | Bytes |
|---|---|---:|
| [AntScope2/AA55BTPacket.cpp](./AntScope2/AA55BTPacket.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/AA55BTPacket.cpp) | 1868 |
| [AntScope2/AA55BTPacket.h](./AntScope2/AA55BTPacket.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/AA55BTPacket.h) | 1848 |
| [AntScope2/AntScope.pro](./AntScope2/AntScope.pro) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/AntScope.pro) | 10582 |
| [AntScope2/Calibration/cal_load.s1p](./AntScope2/Calibration/cal_load.s1p) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/Calibration/cal_load.s1p) | 14125 |
| [AntScope2/Calibration/cal_open.s1p](./AntScope2/Calibration/cal_open.s1p) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/Calibration/cal_open.s1p) | 14144 |
| [AntScope2/Calibration/cal_short.s1p](./AntScope2/Calibration/cal_short.s1p) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/Calibration/cal_short.s1p) | 14144 |
| [AntScope2/LICENSE.txt](./AntScope2/LICENSE.txt) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/LICENSE.txt) | 1078 |
| [AntScope2/README.md](./AntScope2/README.md) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/README.md) | 185 |
| [AntScope2/analyzer/analyzerdata.cpp](./AntScope2/analyzer/analyzerdata.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/analyzerdata.cpp) | 5367 |
| [AntScope2/analyzer/analyzerdata.h](./AntScope2/analyzer/analyzerdata.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/analyzerdata.h) | 1056 |
| [AntScope2/analyzer/analyzerdata.ui](./AntScope2/analyzer/analyzerdata.ui) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/analyzerdata.ui) | 2452 |
| [AntScope2/analyzer/analyzerparameters.h](./AntScope2/analyzer/analyzerparameters.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/analyzerparameters.h) | 16572 |
| [AntScope2/analyzer/analyzerpro.cpp](./AntScope2/analyzer/analyzerpro.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/analyzerpro.cpp) | 25365 |
| [AntScope2/analyzer/analyzerpro.h](./AntScope2/analyzer/analyzerpro.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/analyzerpro.h) | 4635 |
| [AntScope2/analyzer/baseanalyzer.cpp](./AntScope2/analyzer/baseanalyzer.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/baseanalyzer.cpp) | 3232 |
| [AntScope2/analyzer/baseanalyzer.h](./AntScope2/analyzer/baseanalyzer.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/baseanalyzer.h) | 3735 |
| [AntScope2/analyzer/ble_analyzer.cpp](./AntScope2/analyzer/ble_analyzer.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/ble_analyzer.cpp) | 28991 |
| [AntScope2/analyzer/ble_analyzer.h](./AntScope2/analyzer/ble_analyzer.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/ble_analyzer.h) | 7482 |
| [AntScope2/analyzer/com_analyzer.cpp](./AntScope2/analyzer/com_analyzer.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/com_analyzer.cpp) | 36085 |
| [AntScope2/analyzer/com_analyzer.h](./AntScope2/analyzer/com_analyzer.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/com_analyzer.h) | 3311 |
| [AntScope2/analyzer/customanalyzer.cpp](./AntScope2/analyzer/customanalyzer.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/customanalyzer.cpp) | 4545 |
| [AntScope2/analyzer/customanalyzer.h](./AntScope2/analyzer/customanalyzer.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/customanalyzer.h) | 2028 |
| [AntScope2/analyzer/hid_analyzer.cpp](./AntScope2/analyzer/hid_analyzer.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/hid_analyzer.cpp) | 25024 |
| [AntScope2/analyzer/hid_analyzer.h](./AntScope2/analyzer/hid_analyzer.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/hid_analyzer.h) | 3018 |
| [AntScope2/analyzer/nanovna_analyzer.cpp](./AntScope2/analyzer/nanovna_analyzer.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/nanovna_analyzer.cpp) | 12180 |
| [AntScope2/analyzer/nanovna_analyzer.h](./AntScope2/analyzer/nanovna_analyzer.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/analyzer/nanovna_analyzer.h) | 2541 |
| [AntScope2/crc32.cpp](./AntScope2/crc32.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/crc32.cpp) | 5707 |
| [AntScope2/crc32.h](./AntScope2/crc32.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/crc32.h) | 258 |
| [AntScope2/devinfo/redeviceinfo.cpp](./AntScope2/devinfo/redeviceinfo.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/devinfo/redeviceinfo.cpp) | 6283 |
| [AntScope2/devinfo/redeviceinfo.h](./AntScope2/devinfo/redeviceinfo.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/devinfo/redeviceinfo.h) | 1649 |
| [AntScope2/mainwindow.cpp](./AntScope2/mainwindow.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/mainwindow.cpp) | 242944 |
| [AntScope2/mainwindow.h](./AntScope2/mainwindow.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/mainwindow.h) | 10886 |
| [AntScope2/measurements.cpp](./AntScope2/measurements.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/measurements.cpp) | 197753 |
| [AntScope2/measurements.h](./AntScope2/measurements.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/measurements.h) | 10150 |
| [AntScope2/calibration.cpp](./AntScope2/calibration.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/calibration.cpp) | 13843 |
| [AntScope2/calibration.h](./AntScope2/calibration.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/calibration.h) | 10492 |
| [AntScope2/export.cpp](./AntScope2/export.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/export.cpp) | 4671 |
| [AntScope2/export.h](./AntScope2/export.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/export.h) | 863 |
| [AntScope2/settings.cpp](./AntScope2/settings.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/settings.cpp) | 55036 |
| [AntScope2/settings.h](./AntScope2/settings.h) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/settings.h) | 6906 |
| [AntScope2/fqsettings.cpp](./AntScope2/fqsettings.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/fqsettings.cpp) | 1159 |
| [AntScope2/fqsettings.ui](./AntScope2/fqsettings.ui) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/fqsettings.ui) | 2899 |
| [AntScope2/mainwindow.ui](./AntScope2/mainwindow.ui) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/mainwindow.ui) | 34616 |
| [AntScope2/main.cpp](./AntScope2/main.cpp) | [upstream](https://github.com/rigexpert/AntScope2/blob/901923c3029e661385fdf88dc7b089cc2263f609/main.cpp) | 8722 |
| [official/stick-pro-datasheet-en.web-extract.txt](./official/stick-pro-datasheet-en.web-extract.txt) | [upstream](https://rigexpert.com/files/product_documentation/Stick-Pro/Stick-Pro-Aantenna-and-Cable-Analyzer_Datasheet.EN.pdf) | 3240 |
| [official/stick-pro-manual-en.web-extract.txt](./official/stick-pro-manual-en.web-extract.txt) | [upstream](https://rigexpert.com/files/product_documentation/Stick-Pro/Manual-en.pdf) | 9980 |
| [official/stick-pro-manual.web-extract.txt](./official/stick-pro-manual.web-extract.txt) | [upstream](https://old.rigexpert.com/products/uhf-analyzers/stick-pro/users-manual/) | 22122 |
| [official/stick-pro-product.web-extract.txt](./official/stick-pro-product.web-extract.txt) | [upstream](https://rigexpert.com/products/antenna-analyzers/stick-pro/) | 7371 |
