#!/usr/bin/env python3
"""Check oracle consistency. Does not contact hardware or test AetherSDR."""
from pathlib import Path
import cmath
import hashlib
import json
import math
import re
import struct

ROOT = Path(__file__).resolve().parent

def crc8(data):
    value = 0
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = ((value << 1) ^ 0x07) & 0xFF if value & 0x80 else (value << 1) & 0xFF
    return value

manifest = json.loads((ROOT / "sources/manifest.json").read_text())
for record in manifest["files"]:
    path = ROOT / "sources" / record["path"]
    assert path.is_file(), path
    assert path.stat().st_size == record["bytes"], path
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record["sha256"], path

doc = (ROOT / "rigexpert-oracle.md").read_text()
sha = manifest["commit"]
references = re.findall(
    r"https://github\.com/rigexpert/AntScope2/blob/([0-9a-f]{40})/([^\s)\]]+)", doc)
for commit, target in references:
    assert commit == sha, target
    parts = target.split("#", 1)
    path = ROOT / "sources/AntScope2" / parts[0]
    assert path.is_file(), path
    if len(parts) > 1:
        match = re.fullmatch(r"L(\d+)(?:-L(\d+))?", parts[1])
        assert match, target
        first = int(match[1])
        last = int(match[2] or match[1])
        assert 1 <= first <= last <= len(path.read_text().splitlines()), target

declared = set(re.findall(r"^\[([^\]]+)\]:", doc, flags=re.M))
used = set(re.findall(r"\[[^\]]+\]\[([^\]]+)\]", doc))
assert used <= declared, used - declared
for link in re.findall(r"\]\((\./[^)]+)\)", doc):
    assert (ROOT / link.split("#", 1)[0]).is_file(), link

source = (ROOT / "sources/AntScope2/crc32.cpp").read_text()
chunk = source.split("const quint8 CRC8Table[256] = {")[1].split("};")[0]
table = [int(value, 16) for value in re.findall(r"0x[0-9a-fA-F]+", chunk)]
assert len(table) == 256
assert all(crc8(bytes([index])) == entry for index, entry in enumerate(table))
assert crc8(b"123456789") == 0xF4

vectors = json.loads((ROOT / "source-derived-vectors.json").read_text())
assert vectors["source_commit"] == sha
for vector in vectors["vectors"]:
    data = bytes.fromhex(vector["hex"])
    assert len(data) == vector["api_bytes"]
    if vector["kind"] == "usb-hid-command":
        command = vector["ascii"].encode("ascii")
        assert data == (bytes([7, len(command)]) + command).ljust(64, b"\x00")
    elif vector["kind"] == "ble-sweep-command":
        payload = bytes([0x7F]) + struct.pack("<iii", 14175, 350, 100) + bytes(6)
        assert data == payload + bytes([crc8(payload)])
        assert data[-1] == 0x7A
    else:
        raise AssertionError(vector["kind"])

def match_values(z, z0=50.0):
    gamma = (z - z0) / (z + z0)
    mag = abs(gamma)
    swr = (1 + mag) / (1 - mag) if mag < 1 else math.inf
    rl = -20 * math.log10(mag) if mag else math.inf
    return gamma, swr, rl

for z, expected_swr, expected_rl in [
    (50 + 0j, 1, math.inf),
    (100 + 0j, 2, 9.542425094393248),
    (25 + 0j, 2, 9.542425094393248),
    (54 + 0j, 1.08, 28.29946695941636),
    (50 + 50j, 2.618033988749895, 6.9897000433601875),
    (0j, math.inf, 0),
]:
    _, swr, rl = match_values(z)
    assert math.isclose(swr, expected_swr, rel_tol=1e-12)
    assert math.isclose(rl, expected_rl, rel_tol=1e-12, abs_tol=1e-12)

def compressed_value(word):
    mantissa = word & 0x1FFF
    exponent = (word >> 13) & 3
    result = mantissa * 123.0 / 10 ** (exponent + 2)
    return -result if word & 0x8000 else result

assert math.isclose(compressed_value(0x000A), 12.3)
assert math.isclose(compressed_value(0x200A), 1.23)
assert math.isclose(compressed_value(0xA00A), -1.23)
assert math.isclose(compressed_value(0x1FFF), 10074.93)
print(f"PASS: {len(manifest['files'])} source hashes, {len(references)} pinned source references, "
      "local document links, CRC table, synthetic vectors, RF math and packed-value fixtures.")
print("Documentation consistency only. Hardware, AetherSDR builds/tests and RF validation: NOT RUN.")

